/***************************************************************
 * Name:      Projekt_chinczykApp.h
 * Purpose:   Defines Application Class
 * Author:     ()
 * Created:   2023-12-13
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef PROJEKT_CHINCZYKAPP_H
#define PROJEKT_CHINCZYKAPP_H

#include <wx/app.h>

class Projekt_chinczykApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // PROJEKT_CHINCZYKAPP_H
